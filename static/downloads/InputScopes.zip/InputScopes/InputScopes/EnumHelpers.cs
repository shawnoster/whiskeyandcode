﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace InputScopes
{
    public static class EnumHelpers
    {
        public static IEnumerable<string> GetNames(Type enumType)
        {
            if (!enumType.IsEnum)
            {
                throw new InvalidOperationException("Specified generic parameter must be an enumeration.");
            }
            List<string> nameList = new List<String>();

            FieldInfo[] fiArray = enumType.GetFields(BindingFlags.Public | BindingFlags.Static);
            foreach (FieldInfo fi in fiArray)
            {
                nameList.Add(fi.Name);
            }

            return nameList;
        }

        public static IEnumerable<string> GetNames<T>() where T : struct
        {
            return GetNames(typeof(T));
        }

        public static T GetValue<T>(string name) where T : struct
        {
            return (T)(Enum.Parse(typeof(T), name, true));
        }
    }
}
