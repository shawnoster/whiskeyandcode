﻿using System.Linq;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Phone.Controls;

namespace InputScopes
{
    public partial class MainPage : PhoneApplicationPage
    {
        public MainPage()
        {
            InitializeComponent();

            SupportedOrientations = SupportedPageOrientation.Portrait | SupportedPageOrientation.Landscape;

            // populate the listbox with a sorted list of all InputScopes
            listBox1.ItemsSource = EnumHelpers.GetNames<InputScopeNameValue>().OrderBy( n => n);
        }

        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            InputScopeNameValue inputScope = EnumHelpers.GetValue<InputScopeNameValue>((string)e.AddedItems[0]);
            textBox1.InputScope = new InputScope()
            {
                Names = { new InputScopeName() { NameValue = InputScopeNameValue.Text } }
            };
        }
    }
}