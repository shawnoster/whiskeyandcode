﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;

namespace YouAreHere
{
    public partial class MainPage : PhoneApplicationPage
    {
        
        private IList<LocationSnapshot> m_locations;

        public MainPage()
        {
            InitializeComponent();

            SupportedOrientations = SupportedPageOrientation.Portrait | SupportedPageOrientation.Landscape;

            m_locations = new ObservableCollection<LocationSnapshot>();
            LocationListBox.ItemsSource = m_locations;
        }

        private void TakeSnapshotButton_Click(object sender, RoutedEventArgs e)
        {
            DotAnimation.Begin();

            LocationSnapshot snap = new LocationSnapshot();
            snap.City = "Redmond";
            snap.Note = NoteTextBox.Text;
            snap.Latitude = 13;
            snap.Longitude = -115;

            m_locations.Add(snap);

            this.DataContext = snap;
        }
    }

}